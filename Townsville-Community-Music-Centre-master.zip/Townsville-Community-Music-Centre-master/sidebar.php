<div class="col-md-4 col-lg-3" style="">
  <div style="border: 1px grey solid;
    padding: 10px;">
    We have performance opportunities available throughout 2017 for local musicians and organisations.<br>
    <a href="" class=" white-space-normal">Find out more...</a><br><br>

    <div class="text-center">
      <a href="" class="btn btn-primary btn-lg white-space-normal">Volunteers wanted</a><br><br>
      <a href="" class="btn btn-primary btn-lg white-space-normal">Live House Music</a><br><br>
      <a href="" class="btn btn-primary btn-lg white-space-normal">Volunteers wanted</a><br><br>
      <p>Are you new to Townsville?</p>
      <a href="" class="btn btn-primary white-space-normal">Information for new arrivals</a><br><br>
      <img class="" src="images/SiteImages/TCCcolour150193.gif">
      <img class="" src="images/SiteImages/Qldlogo150200.png">
    </div>
  </div>
</div>
